import p_img1 from "./p_img1.png";
import p_img1_1 from "./p_img1_1.png";
import p_img2_1 from "./p_img2_1.png";
import p_img2_2 from "./p_img2_2.png";
import p_img2_3 from "./p_img2_3.png";
import p_img2_4 from "./p_img2_4.png";
import p_img3 from "./p_img3.png";
import p_img4 from "./p_img4.png";
import p_img5 from "./p_img5.png";
import p_img6 from "./p_img6.png";
import p_img7 from "./p_img7.png";
import p_img8 from "./p_img8.png";
import p_img9 from "./p_img9.png";
import p_img10 from "./p_img10.png";
import p_img11 from "./p_img11.png";
import p_img12 from "./p_img12.png";
import p_img13 from "./p_img13.png";
import p_img14 from "./p_img14.png";
import p_img15 from "./p_img15.png";
import p_img16 from "./p_img16.png";
import p_img17 from "./p_img17.png";
import p_img18 from "./p_img18.png";
import p_img19 from "./p_img19.png";
import p_img20 from "./p_img20.png";
import p_img21 from "./p_img21.png";
import p_img22 from "./p_img22.png";
import p_img23 from "./p_img23.png";
import p_img24 from "./p_img24.png";
import p_img26 from "./p_img26.png";
import p_img27_1 from "./p_img27_1.png";
import p_img27_2 from "./p_img27_2.png";
import p_img28 from "./p_img28.png";
import p_img29 from "./p_img29.png";
import p_img30 from "./p_img30.png";
import p_img31 from "./p_img31.png";
import p_img32 from "./p_img32.png";
import p_img33 from "./p_img33.png";
import p_img34 from "./p_img34.png";
import p_img35 from "./p_img35.png";
import p_img36 from "./p_img36.png";
import p_img37 from "./p_img37.png";
import p_img38 from "./p_img38.png";
import p_img39 from "./p_img39.png";
import p_img40 from "./p_img40.png";
import p_img41 from "./p_img41.png";
import p_img42 from "./p_img42.png";
import p_img43 from "./p_img43.png";
import p_img44 from "./p_img44.png";
import p_img45 from "./p_img45.png";
import p_img46 from "./p_img46.png";
import p_img47 from "./p_img47.png";
import p_img48 from "./p_img48.png";
import p_img49 from "./p_img49.png";
import p_img50 from "./p_img50.png";
import p_img51 from "./p_img51.png";
import p_img52 from "./p_img52.png";
import p_img53 from "./p_img53.png";
import p_img54_1 from "./p_img54_1.png";
import p_img54_2 from "./p_img54_2.png";
import p_img55_1 from "./p_img55_1.png";
import p_img55_2 from "./p_img55_2.png";
import p_img56_1 from "./p_img56_1.png";
import p_img56_2 from "./p_img56_2.png";
import p_img57_1 from "./p_img57_1.png";
import p_img57_2 from "./p_img57_2.png";
import p_img58_1 from "./p_img58_1.png";
import p_img58_2 from "./p_img58_2.png";
import p_img59_1 from "./p_img59_1.png";
import p_img59_2 from "./p_img59_2.png";
import p_img60_1 from "./p_img60_1.png";
import p_img60_2 from "./p_img60_2.png";
import p_img61 from "./p_img61.png";
import p_img62_1 from "./p_img62_1.png";
import p_img62_2 from "./p_img62_2.png";
import p_img63_1 from "./p_img63_1.png";
import p_img63_2 from "./p_img63_2.png";
import p_img64_1 from "./p_img64_1.png";
import p_img64_2 from "./p_img64_2.png";
import p_img65_1 from "./p_img65_1.png";
import p_img65_2 from "./p_img65_2.png";
import p_img66_1 from "./p_img66_1.png";
import p_img66_2 from "./p_img66_2.png";
import p_img68 from "./p_img68.png";
import p_img69_1 from "./p_img69_1.png";
import p_img69_2 from "./p_img69_2.png";
import p_img70_1 from "./p_img70_1.png";
import p_img70_2 from "./p_img70_2.png";
import p_img71_1 from "./p_img71_1.png";
import p_img71_2 from "./p_img71_2.png";
import p_img72_1 from "./p_img72_1.png";
import p_img72_2 from "./p_img72_2.png";
import p_img73_1 from "./p_img73_1.png";
import p_img73_2 from "./p_img73_2.png";
import p_img74_1 from "./p_img74_1.png";
import p_img74_2 from "./p_img74_2.png";
import p_img75_1 from "./p_img75_1.png";
import p_img75_2 from "./p_img75_2.png";
import p_img76_1 from "./p_img76_1.png";
import p_img76_2 from "./p_img76_2.png";
import p_img77 from "./p_img77.png";
import p_img67_1 from "./p_img67_1.png";
import p_img67_2 from "./p_img67_2.png";

import logo from "./logo.png";
import hero_img from "./hero_img.png";
import cart_icon from "./cart_icon.png";
import bin_icon from "./bin_icon.png";
import dropdown_icon from "./dropdown_icon.png";
import exchange_icon from "./exchange_icon.png";
import profile_icon from "./profile_icon.png";
import quality_icon from "./quality_icon.png";
import search_icon from "./search_icon.png";
import star_dull_icon from "./star_dull_icon.png";
import star_icon from "./star_icon.png";
import support_img from "./support_img.png";
import menu_icon from "./menu_icon.png";
import about_img from "./about_img.png";
import contact_img from "./contact_img.png";
// import razorpay_logo from "./razorpay_logo.png";
import stripe_logo from "./stripe_logo.png";
import cross_icon from "./cross_icon.png";

export const assets = {
  logo,
  hero_img,
  cart_icon,
  dropdown_icon,
  exchange_icon,
  profile_icon,
  quality_icon,
  search_icon,
  star_dull_icon,
  star_icon,
  bin_icon,
  support_img,
  menu_icon,
  about_img,
  contact_img,
  // razorpay_logo,
  stripe_logo,
  cross_icon,
};

export const products = [
  {
    _id: "aaaaa",
    name: "Green Midi Dress",
    description: "Dark Green Off-the-Shoulder Midi Dress",
    price: 50,
    image: [p_img1, p_img1_1],
    category: "Women",
    subCategory: "Dresses",
    sizes: ["S", "M", "L"],
    date: 1716634345448,
    bestseller: true,
  },
  {
    _id: "aabea",
    name: "White Lace Off-the-Shoulder",
    description: "White Lace Off-the-Shoulder Maxi Dress",
    price: 260,
    image: [p_img56_1, p_img56_2],
    category: "Women",
    subCategory: "Weddings",
    sizes: ["S", "M", "L"],
    date: 1716634345448,
    bestseller: false,
  },
  {
    _id: "aabfa",
    name: "Pleated Midi Dress",
    description: "Emerald Green Tie-Strap Pleated Midi Dress",
    price: 39,
    image: [p_img57_1, p_img57_2],
    category: "Women",
    subCategory: "Dresses",
    sizes: ["S", "M", "L"],
    date: 1716634345448,
    bestseller: false,
  },
  {
    _id: "aabga",
    name: "Satin Asymmetrical Dress",
    description: "Olive Green Satin Asymmetrical Midi Dress",
    price: 79,
    image: [p_img58_1, p_img58_2],
    category: "Women",
    subCategory: "Dresses",
    sizes: ["S", "M", "L"],
    date: 1716634345448,
    bestseller: true,
  },
  {
    _id: "aabhq",
    name: "Ruffled Mini Dress",
    description: "Black Tulle Tiered Ruffled Mini Dress",
    price: 88,
    image: [p_img59_1, p_img59_2],
    category: "Women",
    subCategory: "Dresses",
    sizes: ["S", "M", "L"],
    date: 1716634345448,
    bestseller: true,
  },
  {
    _id: "aabia",
    name: "Trendy Finesse Off-the-Shoulder Top",
    description:
      "Trendy Finesse Taupe Abstract Mesh Ruched Off-the-Shoulder Top",
    price: 40,
    image: [p_img60_1, p_img60_2],
    category: "Women",
    subCategory: "Topwear",
    sizes: ["S", "M", "L"],
    date: 1716634345448,
    bestseller: false,
  },
  {
    _id: "aabja",
    name: "Brown Crocodile Pointed-Toe Slides",
    description: "Brown Crocodile Embossed Pointed-Toe Slides",
    price: 32,
    image: [p_img61],
    category: "Women",
    subCategory: "Shoes",
    sizes: ["6", "7", "8"],
    date: 1716634345448,
    bestseller: false,
  },
  {
    _id: "aabka",
    name: "Satin Wrap Dress",
    description: "Navy Blue Floral Print Satin Wrap Dress",
    price: 12,
    image: [p_img62_1, p_img62_2],
    category: "Women",
    subCategory: "Dresses",
    sizes: ["S", "M", "L"],
    date: 1716634345448,
    bestseller: false,
  },
  {
    _id: "aabla",
    name: "White Long Sleeve Mermaid",
    description: "White Long Sleeve Mermaid Maxi Dress",
    price: 230,
    image: [p_img63_1, p_img63_2],
    category: "Women",
    subCategory: "Weddings",
    sizes: ["S", "M", "L"],
    date: 1716634345448,
    bestseller: false,
  },
  {
    _id: "aabma",
    name: "Bustier Midi Dress",
    description: "White Sequin Pearl Bustier Midi Dress",
    price: 30,
    image: [p_img64_1, p_img64_2],
    category: "Women",
    subCategory: "Dresses",
    sizes: ["S", "M", "L"],
    date: 1716634345448,
    bestseller: false,
  },
  {
    _id: "aabna",
    name: "Lace-Up Dress",
    description: "Satin Floral Lace-Up Midi Dress",
    price: 21,
    image: [p_img65_1, p_img65_2],
    category: "Women",
    subCategory: "Dresses",
    sizes: ["S", "M", "L"],
    date: 1716634345448,
    bestseller: false,
  },
  {
    _id: "aaaac",
    name: "Girls Round Neck Cotton Top",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 22,
    image: [p_img3],
    category: "Kids",
    subCategory: "Dresses",
    sizes: ["S", "L", "XL"],
    date: 1716234545448,
    bestseller: false,
  },
  {
    _id: "aabba",
    name: "Ankle Strap Heels",
    description: "Ankle Strap Heels",
    price: 28,
    image: [p_img53],
    category: "Women",
    subCategory: "Shoes",
    sizes: ["6", "7", "8"],
    date: 1716634345448,
    bestseller: false,
  },
  {
    _id: "aabca",
    name: "Denim Mini Skirt",
    description: "Denim Mini Skirt",
    price: 37,
    image: [p_img54_1, p_img54_2],
    category: "Women",
    subCategory: "Bottoms",
    sizes: ["S", "M", "L"],
    date: 1716634345448,
    bestseller: false,
  },
  {
    _id: "aabda",
    name: "Black Notched Strapless Bodysuit",
    description: "Black Notched Strapless Bodysuit",
    price: 29,
    image: [p_img55_1, p_img55_2],
    category: "Women",
    subcategory: "Topwear",
    sizes: ["6", "7", "8"],
    date: 1716634345448,
    bestseller: false,
  },
  {
    _id: "aaaad",
    name: "Men Round Neck Pure Cotton T-shirt",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 20,
    image: [p_img4],
    category: "Men",
    subCategory: "Topwear",
    sizes: ["S", "M", "XXL"],
    date: 1716621345448,
    bestseller: false,
  },
  {
    _id: "aaaae",
    name: "Women Round Neck Cotton Top",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 30,
    image: [p_img5],
    category: "Women",
    subCategory: "Topwear",
    sizes: ["M", "L", "XL"],
    date: 1716622345448,
    bestseller: false,
  },
  {
    _id: "aaaaf",
    name: "Girls Round Neck Cotton Top",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 14,
    image: [p_img6],
    category: "Kids",
    subCategory: "Topwear",
    sizes: ["S", "L", "XL"],
    date: 1716623423448,
    bestseller: false,
  },
  {
    _id: "aaaag",
    name: "Men Tapered Fit Flat-Front Trousers",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 19,
    image: [p_img7],
    category: "Men",
    subCategory: "Bottoms",
    sizes: ["S", "M", "L"],
    date: 1716621542448,
    bestseller: false,
  },
  {
    _id: "aabpa",
    name: "Romance White Lace Dress",
    description: "Romance White Lace Sleeveless Mermaid Maxi Dress",
    price: 189,
    image: [p_img27_1, p_img27_2],
    category: "Women",
    subCategory: "Weddings",
    sizes: ["S", "M", "L"],
    date: 1716634345448,
    bestseller: false,
  },
  {
    _id: "aaaah",
    name: "Men Round Neck Pure Cotton T-shirt",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 24,
    image: [p_img8],
    category: "Men",
    subCategory: "Topwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716622345448,
    bestseller: false,
  },
  {
    _id: "aaaab",
    name: "Pink Polo T-shirt",
    description: "Pink Polo T-shirt with white color",
    price: 28,
    image: [p_img2_1, p_img2_3],
    category: "Men",
    subCategory: "Topwear",
    sizes: ["M", "L", "XL"],
    date: 1716621345448,
    bestseller: false,
  },
  {
    _id: "aaaai",
    name: "Girls Round Neck Cotton Top",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 10,
    image: [p_img9],
    category: "Kids",
    subCategory: "Topwear",
    sizes: ["M", "L", "XL"],
    date: 1716621235448,
    bestseller: false,
  },
  {
    _id: "aaaaj",
    name: "Men Tapered Fit Flat-Front Trousers",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 21,
    image: [p_img10],
    category: "Men",
    subCategory: "Bottoms",
    sizes: ["S", "L", "XL"],
    date: 1716622235448,
    bestseller: false,
  },
  {
    _id: "aaaak",
    name: "Men Round Neck Pure Cotton T-shirt",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 20,
    image: [p_img11],
    category: "Men",
    subCategory: "Topwear",
    sizes: ["S", "M", "L"],
    date: 1716623345448,
    bestseller: false,
  },
  {
    _id: "aaaal",
    name: "Men Round Neck Pure Cotton T-shirt",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 41,
    image: [p_img12],
    category: "Men",
    subCategory: "Topwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716624445448,
    bestseller: false,
  },
  {
    _id: "aaboa",
    name: "Beige High-Waisted Side Button Skirt",
    description: "Beige High-Waisted Side Button Midi Skirt",
    price: 47,
    image: [p_img66_1, p_img66_2],
    category: "Women",
    subCategory: "Bottoms",
    sizes: ["S", "M", "L"],
    date: 1716634345448,
    bestseller: false,
  },
  {
    _id: "aaaam",
    name: "Women Round Neck Cotton Top",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 30,
    image: [p_img13],
    category: "Women",
    subCategory: "Topwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716625545448,
    bestseller: false,
  },
  {
    _id: "aaaan",
    name: "Boy Round Neck Pure Cotton T-shirt",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 16,
    image: [p_img14],
    category: "Kids",
    subCategory: "Topwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716626645448,
    bestseller: false,
  },
  {
    _id: "aaaao",
    name: "Men Tapered Fit Flat-Front Trousers",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 40,
    image: [p_img15],
    category: "Men",
    subCategory: "Bottoms",
    sizes: ["S", "M", "L", "XL"],
    date: 1716627745448,
    bestseller: false,
  },
  {
    _id: "aaaap",
    name: "Girls Round Neck Cotton Top",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 17,
    image: [p_img16],
    category: "Kids",
    subCategory: "Topwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716628845448,
    bestseller: false,
  },
  {
    _id: "aaaaq",
    name: "Men Tapered Fit Flat-Front Trousers",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 15,
    image: [p_img17],
    category: "Men",
    subCategory: "Bottoms",
    sizes: ["S", "M", "L", "XL"],
    date: 1716629945448,
    bestseller: false,
  },
  {
    _id: "aaaar",
    name: "Boy Round Neck Pure Cotton T-shirt",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 18,
    image: [p_img18],
    category: "Kids",
    subCategory: "Topwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716631045448,
    bestseller: false,
  },
  {
    _id: "aaaas",
    name: "Boy Round Neck Pure Cotton T-shirt",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 16,
    image: [p_img19],
    category: "Kids",
    subCategory: "Topwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716632145448,
    bestseller: false,
  },
  {
    _id: "aaaat",
    name: "Women Palazzo Pants with Waist Belt",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 19,
    image: [p_img20],
    category: "Women",
    subCategory: "Bottoms",
    sizes: ["S", "M", "L", "XL"],
    date: 1716633245448,
    bestseller: false,
  },
  {
    _id: "aaaau",
    name: "Women Zip-Front Relaxed Fit Jacket",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 17,
    image: [p_img21],
    category: "Women",
    subCategory: "Winterwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716634345448,
    bestseller: false,
  },
  {
    _id: "aaaav",
    name: "Women Palazzo Pants with Waist Belt",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 20,
    image: [p_img22],
    category: "Women",
    subCategory: "Bottoms",
    sizes: ["S", "M", "L", "XL"],
    date: 1716635445448,
    bestseller: false,
  },
  {
    _id: "aaaaw",
    name: "Boy Round Neck Pure Cotton T-shirt",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 18,
    image: [p_img23],
    category: "Kids",
    subCategory: "Topwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716636545448,
    bestseller: false,
  },
  {
    _id: "aaaax",
    name: "Boy Round Neck Pure Cotton T-shirt",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 21,
    image: [p_img24],
    category: "Kids",
    subCategory: "Topwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716637645448,
    bestseller: false,
  },

  {
    _id: "aaaaz",
    name: "Women Zip-Front Relaxed Fit Jacket",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 22,
    image: [p_img26],
    category: "Women",
    subCategory: "Winterwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716639845448,
    bestseller: false,
  },

  {
    _id: "aaabb",
    name: "Men Slim Fit Relaxed Denim Jacket",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 23,
    image: [p_img28],
    category: "Men",
    subCategory: "Winterwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716642045448,
    bestseller: false,
  },
  {
    _id: "aaabc",
    name: "Women Round Neck Cotton Top",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 21,
    image: [p_img29],
    category: "Women",
    subCategory: "Topwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716643145448,
    bestseller: false,
  },
  {
    _id: "aaabd",
    name: "Girls Round Neck Cotton Top",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 24,
    image: [p_img30],
    category: "Kids",
    subCategory: "Topwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716644245448,
    bestseller: false,
  },
  {
    _id: "aaabe",
    name: "Men Round Neck Pure Cotton T-shirt",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 22,
    image: [p_img31],
    category: "Men",
    subCategory: "Topwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716645345448,
    bestseller: false,
  },
  {
    _id: "aaabf",
    name: "Men Round Neck Pure Cotton T-shirt",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 25,
    image: [p_img32],
    category: "Men",
    subCategory: "Topwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716646445448,
    bestseller: false,
  },
  {
    _id: "aaabg",
    name: "Girls Round Neck Cotton Top",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 23,
    image: [p_img33],
    category: "Kids",
    subCategory: "Topwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716647545448,
    bestseller: false,
  },
  {
    _id: "aaabh",
    name: "Women Round Neck Cotton Top",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 26,
    image: [p_img34],
    category: "Women",
    subCategory: "Topwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716648645448,
    bestseller: false,
  },
  {
    _id: "aaabi",
    name: "Women Zip-Front Relaxed Fit Jacket",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 24,
    image: [p_img35],
    category: "Women",
    subCategory: "Winterwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716649745448,
    bestseller: false,
  },
  {
    _id: "aaabj",
    name: "Women Zip-Front Relaxed Fit Jacket",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 27,
    image: [p_img36],
    category: "Women",
    subCategory: "Winterwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716650845448,
    bestseller: false,
  },
  {
    _id: "aaabk",
    name: "Women Round Neck Cotton Top",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 25,
    image: [p_img37],
    category: "Women",
    subCategory: "Topwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716651945448,
    bestseller: false,
  },
  {
    _id: "aaabl",
    name: "Men Round Neck Pure Cotton T-shirt",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 28,
    image: [p_img38],
    category: "Men",
    subCategory: "Topwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716653045448,
    bestseller: false,
  },
  {
    _id: "aaabm",
    name: "Men Printed Plain Cotton Shirt",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 26,
    image: [p_img39],
    category: "Men",
    subCategory: "Topwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716654145448,
    bestseller: false,
  },
  {
    _id: "aaabn",
    name: "Men Slim Fit Relaxed Denim Jacket",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 29,
    image: [p_img40],
    category: "Men",
    subCategory: "Winterwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716655245448,
    bestseller: false,
  },
  {
    _id: "aaabo",
    name: "Men Round Neck Pure Cotton T-shirt",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 27,
    image: [p_img41],
    category: "Men",
    subCategory: "Topwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716656345448,
    bestseller: false,
  },
  {
    _id: "aaabp",
    name: "Boy Round Neck Pure Cotton T-shirt",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 30,
    image: [p_img42],
    category: "Kids",
    subCategory: "Topwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716657445448,
    bestseller: false,
  },
  {
    _id: "aaabq",
    name: "Kid Tapered Slim Fit Trouser",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 28,
    image: [p_img43],
    category: "Kids",
    subCategory: "Bottoms",
    sizes: ["S", "M", "L", "XL"],
    date: 1716658545448,
    bestseller: false,
  },
  {
    _id: "aaabr",
    name: "Women Zip-Front Relaxed Fit Jacket",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 31,
    image: [p_img44],
    category: "Women",
    subCategory: "Winterwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716659645448,
    bestseller: false,
  },
  {
    _id: "aaabs",
    name: "Men Slim Fit Relaxed Denim Jacket",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 29,
    image: [p_img45],
    category: "Men",
    subCategory: "Winterwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716660745448,
    bestseller: false,
  },
  {
    _id: "aaabt",
    name: "Men Slim Fit Relaxed Denim Jacket",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 32,
    image: [p_img46],
    category: "Men",
    subCategory: "Winterwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716661845448,
    bestseller: false,
  },
  {
    _id: "aaabu",
    name: "Kid Tapered Slim Fit Trouser",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 30,
    image: [p_img47],
    category: "Kids",
    subCategory: "Bottoms",
    sizes: ["S", "M", "L", "XL"],
    date: 1716662945448,
    bestseller: false,
  },
  {
    _id: "aaabv",
    name: "Men Slim Fit Relaxed Denim Jacket",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 33,
    image: [p_img48],
    category: "Men",
    subCategory: "Winterwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716664045448,
    bestseller: false,
  },
  {
    _id: "aaabw",
    name: "Kid Tapered Slim Fit Trouser",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 31,
    image: [p_img49],
    category: "Kids",
    subCategory: "Bottoms",
    sizes: ["S", "M", "L", "XL"],
    date: 1716665145448,
    bestseller: false,
  },
  {
    _id: "aaabx",
    name: "Kid Tapered Slim Fit Trouser",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 34,
    image: [p_img50],
    category: "Kids",
    subCategory: "Bottoms",
    sizes: ["S", "M", "L", "XL"],
    date: 1716666245448,
    bestseller: false,
  },
  {
    _id: "aaaby",
    name: "Women Zip-Front Relaxed Fit Jacket",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 32,
    image: [p_img51],
    category: "Women",
    subCategory: "Winterwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716667345448,
    bestseller: false,
  },
  {
    _id: "aaabz",
    name: "Men Slim Fit Relaxed Denim Jacket",
    description:
      "A lightweight, usually knitted, pullover shirt, close-fitting and with a round neckline and short sleeves, worn as an undershirt or outer garment.",
    price: 35,
    image: [p_img52],
    category: "Men",
    subCategory: "Winterwear",
    sizes: ["S", "M", "L", "XL"],
    date: 1716668445448,
    bestseller: false,
  },
  {
    _id: "aabta",
    name: "Light Pink Ruched",
    description: "Light Pink Ruched Lace-Up Bodycon Mini Drees",
    price: 35,
    image: [p_img70_1, p_img70_2],
    category: "Women",
    subCategory: "Dresses",
    sizes: ["S", "M", "L", "XL"],
    date: 1716668445448,
    bestseller: true,
  },
  {
    _id: "aabua",
    name: "Emerald Green Satin Floral Jacquard",
    description: "Simply Dreamy Emerald Green Satin Floral Jacquard Maxi Dress",
    price: 79,
    image: [p_img71_1, p_img71_2],
    category: "Women",
    subCategory: "Dresses",
    sizes: ["S", "M", "L", "XL"],
    date: 1716668445448,
    bestseller: true,
  },
  {
    _id: "aabva",
    name: "Blue Satin Mini Dress",
    description: "Blue Satin Mini Dress",
    price: 69,
    image: [p_img72_1, p_img72_2],
    category: "Women",
    subCategory: "Dresses",
    sizes: ["S", "M", "L", "XL"],
    date: 1716668445448,
    bestseller: true,
  },
  {
    _id: "aabwa",
    name: "Floral Embroidered Midi Dress",
    description: "Impressive Blossom Black 3D Floral Embroidered Midi Dress",
    price: 78,
    image: [p_img73_1, p_img73_2],
    category: "Women",
    subCategory: "Dresses",
    sizes: ["S", "M", "L", "XL"],
    date: 1716668445448,
    bestseller: true,
  },
  {
    _id: "aabya",
    name: "Blush Maxi Dress",
    description: "Heavenly Hues Blush Maxi Dress",
    price: 58,
    image: [p_img74_1, p_img74_2],
    category: "Women",
    subCategory: "Dresses",
    sizes: ["S", "M", "L", "XL"],
    date: 1716668445448,
    bestseller: true,
  },
  {
    _id: "abbaa",
    name: "Floral Applique Bustier",
    description:
      "Notable Elegance Black Mesh Floral Applique Bustier Midi Dress",
    price: 70,
    image: [p_img75_1, p_img75_2],
    category: "Women",
    subCategory: "Dresses",
    sizes: ["S", "M", "L", "XL"],
    date: 1716668445448,
    bestseller: true,
  },
  {
    _id: "abcaa",
    name: "Ivory Linen Skirt",
    description: "Ivory Linen Button-Front Midi Skirt",
    price: 42,
    image: [p_img76_1, p_img76_2],
    category: "Women",
    subCategory: "Bottoms",
    sizes: ["S", "M", "L", "XL"],
    date: 1716668445448,
    bestseller: true,
  },
  {
    _id: "abdaa",
    name: "Velvet Bow High Heel",
    description: "Kendyl Blush Velvet Bow High Heel",
    price: 35,
    image: [p_img77],
    category: "Women",
    subCategory: "Shoes",
    sizes: ["6", "7", "8"],
    date: 1716668445448,
    bestseller: false,
  },
  {
    _id: "abdbb",
    name: "Light Nude Suede Platform Wedges",
    description: "Kendyl Blush Velvet Bow High Heel",
    price: 35,
    image: [p_img68],
    category: "Women",
    subCategory: "Shoes",
    sizes: ["6", "7", "8"],
    date: 1716668445448,
    bestseller: false,
  },
  {
    _id: "abdac",
    name: "Red Tie Strip Mini Dress",
    description: "Red Tie Strip Mini Dress",
    price: 42,
    image: [p_img67_1, p_img67_2],
    category: "Women",
    subCategory: "Dresses",
    sizes: ["S", "M", "L"],
    date: 1716668445448,
    bestseller: false,
  },
  {
    _id: "abdad",
    name: "Ivory Lace Sleeveless Dress",
    description: "Ivory Lace Sleeveless Dress",
    price: 69,
    image: [p_img69_1, p_img69_2],
    category: "Women",
    subCategory: "Weddings",
    sizes: ["S", "M", "L"],
    date: 1716668445448,
    bestseller: false,
  }

];
